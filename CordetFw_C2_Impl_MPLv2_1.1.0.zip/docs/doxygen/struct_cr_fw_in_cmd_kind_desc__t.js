var struct_cr_fw_in_cmd_kind_desc__t =
[
    [ "abortAction", "struct_cr_fw_in_cmd_kind_desc__t.html#a84f958eac4e32b76310cbb48a8c2760e", null ],
    [ "discriminant", "struct_cr_fw_in_cmd_kind_desc__t.html#a1545841e5040c75be6843488e4c62abd", null ],
    [ "isReady", "struct_cr_fw_in_cmd_kind_desc__t.html#ac663f021e2196e284d306d70f39e2310", null ],
    [ "isValid", "struct_cr_fw_in_cmd_kind_desc__t.html#a0731344571f510686d6b8ecc5b47d520", null ],
    [ "progressAction", "struct_cr_fw_in_cmd_kind_desc__t.html#ab2b64c9e41ce3a6c5a7bca925d3820a4", null ],
    [ "servSubType", "struct_cr_fw_in_cmd_kind_desc__t.html#af8abff9c7382feb2e91606172a2287b1", null ],
    [ "servType", "struct_cr_fw_in_cmd_kind_desc__t.html#ad35d0faab4b71f7a0dd67c55e26c9756", null ],
    [ "startAction", "struct_cr_fw_in_cmd_kind_desc__t.html#af4ec8345b5d52994e152924d4d68c4ca", null ],
    [ "terminationAction", "struct_cr_fw_in_cmd_kind_desc__t.html#a7df6654da7127e224b8d626629618dfc", null ]
];