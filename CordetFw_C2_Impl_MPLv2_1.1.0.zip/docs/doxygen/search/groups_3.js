var searchData=
[
  ['management_20of_20incoming_20commands_20and_20reports_2403',['Management of Incoming Commands and Reports',['../group__in_mng_group.html',1,'']]],
  ['management_20of_20outgoing_20commands_20and_20reports_2404',['Management of Outgoing Commands and Reports',['../group__out_mng_group.html',1,'']]]
];
