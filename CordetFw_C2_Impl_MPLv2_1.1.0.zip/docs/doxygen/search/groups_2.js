var searchData=
[
  ['configurable_20header_20files_2401',['Configurable Header Files',['../group__cr_config_group.html',1,'']]],
  ['cordet_20framework_2402',['CORDET Framework',['../group__cr_fw.html',1,'']]]
];
