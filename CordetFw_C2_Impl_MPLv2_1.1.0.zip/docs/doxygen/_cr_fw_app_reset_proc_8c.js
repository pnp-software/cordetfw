var _cr_fw_app_reset_proc_8c =
[
    [ "CrFwAppSmGetAppResetProc", "_cr_fw_app_reset_proc_8c.html#a97d212ef992d44735bb4efe810eb6a8a", null ],
    [ "resetPrDesc", "_cr_fw_app_reset_proc_8c.html#ada2c14fa68d3dee5e8b28d7d864763e4", null ]
];