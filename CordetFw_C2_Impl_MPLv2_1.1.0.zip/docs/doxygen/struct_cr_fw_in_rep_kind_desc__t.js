var struct_cr_fw_in_rep_kind_desc__t =
[
    [ "discriminant", "struct_cr_fw_in_rep_kind_desc__t.html#a1545841e5040c75be6843488e4c62abd", null ],
    [ "isValid", "struct_cr_fw_in_rep_kind_desc__t.html#af7f9f6cca5cd0b15de65ce6ea1ee2621", null ],
    [ "servSubType", "struct_cr_fw_in_rep_kind_desc__t.html#af8abff9c7382feb2e91606172a2287b1", null ],
    [ "servType", "struct_cr_fw_in_rep_kind_desc__t.html#ad35d0faab4b71f7a0dd67c55e26c9756", null ],
    [ "updateAction", "struct_cr_fw_in_rep_kind_desc__t.html#a5e9997a9f7907dfe019daff932983a5e", null ]
];