var cordetfw_examples_2src_2_cr_config_demo_slave1_2_cr_fw_time_8c =
[
    [ "CrFwGetCurrentCycTime", "cordetfw-examples_2src_2_cr_config_demo_slave1_2_cr_fw_time_8c.html#a51ae608bf472256a1fb09a37f07b1878", null ],
    [ "CrFwGetCurrentTime", "cordetfw-examples_2src_2_cr_config_demo_slave1_2_cr_fw_time_8c.html#a280a0fb573ab378f8b1c701252fcfe95", null ],
    [ "CrFwGetCurrentTimeStamp", "cordetfw-examples_2src_2_cr_config_demo_slave1_2_cr_fw_time_8c.html#a3d36f747ab9a1d88ea0d111d0a3320db", null ],
    [ "CrFwStdTimeToTimeStamp", "cordetfw-examples_2src_2_cr_config_demo_slave1_2_cr_fw_time_8c.html#aeb167ac844f1deebc07f3494483e73a7", null ],
    [ "CrFwTimeStampToStdTime", "cordetfw-examples_2src_2_cr_config_demo_slave1_2_cr_fw_time_8c.html#a3cc964362f9067f74de149343552f4a9", null ],
    [ "dummyTime", "cordetfw-examples_2src_2_cr_config_demo_slave1_2_cr_fw_time_8c.html#a08ff7d3937776b580f20601f08b6cacf", null ]
];