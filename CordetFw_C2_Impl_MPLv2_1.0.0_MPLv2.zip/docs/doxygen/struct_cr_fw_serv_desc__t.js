var struct_cr_fw_serv_desc__t =
[
    [ "isDiscriminantEnabled", "struct_cr_fw_serv_desc__t.html#ac373ef390abc8a5ac2f7552fa1cb9aae", null ],
    [ "isServSubTypeEnabled", "struct_cr_fw_serv_desc__t.html#a2a0a9063379375beaa983a8fc9545ee2", null ],
    [ "isServTypeEnabled", "struct_cr_fw_serv_desc__t.html#a27f6d2e962ab56e88e755dd29fa11614", null ],
    [ "lowerBoundDisc", "struct_cr_fw_serv_desc__t.html#a53a1696c2154f9fc767b4de97996cfa9", null ],
    [ "nextServType", "struct_cr_fw_serv_desc__t.html#ad6ea1b28ec333e898be6946461809766", null ],
    [ "servSubType", "struct_cr_fw_serv_desc__t.html#af8abff9c7382feb2e91606172a2287b1", null ],
    [ "servType", "struct_cr_fw_serv_desc__t.html#ad35d0faab4b71f7a0dd67c55e26c9756", null ],
    [ "upperBoundDisc", "struct_cr_fw_serv_desc__t.html#a0f1f42cfc3a24e2ebbfdbe06450ba63f", null ]
];