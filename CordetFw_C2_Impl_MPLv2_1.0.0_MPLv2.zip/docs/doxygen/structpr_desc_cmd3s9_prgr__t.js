var structpr_desc_cmd3s9_prgr__t =
[
    [ "outcome", "structpr_desc_cmd3s9_prgr__t.html#aa6ace86d4828bcae17fc7a98b1becef0", null ],
    [ "sidPtr", "structpr_desc_cmd3s9_prgr__t.html#a4c0b12d1f7ce4c495d87f82779ff2903", null ],
    [ "smDesc", "structpr_desc_cmd3s9_prgr__t.html#a8b7af7ded7754c34418635c2f4772716", null ]
];