var _cr_demo_slave2_2_cr_da_constants_8h =
[
    [ "CR_DA_MASTER", "_cr_demo_slave2_2_cr_da_constants_8h.html#ac2995293cc2261e770353463babe262a", null ],
    [ "CR_DA_SERV_SUBTYPE_DIS", "_cr_demo_slave2_2_cr_da_constants_8h.html#a618035b38263d2091e6cdbc51acde7b0", null ],
    [ "CR_DA_SERV_SUBTYPE_EN", "_cr_demo_slave2_2_cr_da_constants_8h.html#a2f8e163e42f4b65604d4f1611c026183", null ],
    [ "CR_DA_SERV_SUBTYPE_REP", "_cr_demo_slave2_2_cr_da_constants_8h.html#a5ac2b59f582df6e3571fe068000e39e0", null ],
    [ "CR_DA_SERV_SUBTYPE_SET", "_cr_demo_slave2_2_cr_da_constants_8h.html#a04b619347cb3411ae55ea5c2513edee1", null ],
    [ "CR_DA_SERV_TYPE", "_cr_demo_slave2_2_cr_da_constants_8h.html#a3080edffd0347d59be36c306e8a473d2", null ],
    [ "CR_DA_SLAVE_1", "_cr_demo_slave2_2_cr_da_constants_8h.html#ab725fa834d302c32da25e2dc1dbf3616", null ],
    [ "CR_DA_SLAVE_2", "_cr_demo_slave2_2_cr_da_constants_8h.html#ae6fc0ab224d215238d3d129fa905d858", null ],
    [ "CR_DA_SOCKET_PORT", "_cr_demo_slave2_2_cr_da_constants_8h.html#a6e76ace52ea05f3bc3ce6c091ac9c590", null ]
];