var structpr_desc_cmd3s3_start__t =
[
    [ "rdlSlotListPtr", "structpr_desc_cmd3s3_start__t.html#a1f2e887c4048d6c5187c765e5d048663", null ],
    [ "smDesc", "structpr_desc_cmd3s3_start__t.html#a8b7af7ded7754c34418635c2f4772716", null ]
];