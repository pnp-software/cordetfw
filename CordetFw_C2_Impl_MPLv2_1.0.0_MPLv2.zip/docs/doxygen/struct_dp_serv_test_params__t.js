var struct_dp_serv_test_params__t =
[
    [ "AreYouAliveTimeOut", "struct_dp_serv_test_params__t.html#a11db45dd3ef16d88d9e2b843f6c4a2ee", null ],
    [ "OnBoardConnectDestLst", "struct_dp_serv_test_params__t.html#aaaf784f3724dd1ed03c9e8596b07ea78", null ]
];