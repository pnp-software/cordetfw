var NAVTREE =
[
  [ "CORDET Framework - C2 Implementation", "index.html", [
    [ "Introduction", "index.html", null ],
    [ "Verified Items", "verify.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_cr_fw_app_reset_proc_8c.html",
"_cr_fw_constants_8h.html#acd34dab1a3acf7e2c3fbf54fdd17b8f0",
"_cr_fw_in_loader_8c.html#a5c7552e7f5ee72b4ffe9dca2c6ca26ff",
"_cr_fw_in_stream_8h.html#add8b6dc2c35cb99874a396bf386adb3a",
"_cr_fw_out_factory_8c.html#a4d17e4ae6f9255d56026512dfbdd39fb",
"_cr_fw_out_stream_socket_8c.html#aefdd831ed1cd73e50f980063361576ba",
"_cr_fw_rep_in_cmd_outcome_8c.html",
"globals_func.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';