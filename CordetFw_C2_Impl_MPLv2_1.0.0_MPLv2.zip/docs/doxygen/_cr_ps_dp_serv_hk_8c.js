var _cr_ps_dp_serv_hk_8c =
[
    [ "initDpServHk", "_cr_ps_dp_serv_hk_8c.html#a17dd0970000390765868b5d8ee699ad9", null ],
    [ "dpServHkParams", "_cr_ps_dp_serv_hk_8c.html#a9ea568336f81e33a2687e277b0757e12", null ],
    [ "dpServHkVars", "_cr_ps_dp_serv_hk_8c.html#a12663ba3455d5c078f99f1193cb0b91e", null ]
];