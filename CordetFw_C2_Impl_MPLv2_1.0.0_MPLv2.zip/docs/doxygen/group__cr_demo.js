var group__cr_demo =
[
    [ "Master Application", "group__cr_demo_master.html", "group__cr_demo_master" ],
    [ "Slave 1 Application", "group__cr_demo_slave1.html", "group__cr_demo_slave1" ],
    [ "Slave 2 Application", "group__cr_demo_slave2.html", "group__cr_demo_slave2" ],
    [ "Configurable Part of Master Application", "group__cr_config_demo_master.html", "group__cr_config_demo_master" ],
    [ "Configurable Part of Slave 1 Application", "group__cr_config_demo_slave1.html", "group__cr_config_demo_slave1" ],
    [ "Configurable Part of Slave 2 Application", "group__cr_config_demo_slave2.html", "group__cr_config_demo_slave2" ]
];