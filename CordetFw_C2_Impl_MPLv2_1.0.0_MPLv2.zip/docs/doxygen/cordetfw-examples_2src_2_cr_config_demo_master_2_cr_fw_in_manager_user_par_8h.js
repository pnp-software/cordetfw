var cordetfw_examples_2src_2_cr_config_demo_master_2_cr_fw_in_manager_user_par_8h =
[
    [ "CR_FW_INMANAGER_PCRLSIZE", "cordetfw-examples_2src_2_cr_config_demo_master_2_cr_fw_in_manager_user_par_8h.html#a485fc0425ccb5f5d498bcff1c8306e01", null ],
    [ "CR_FW_NOF_INMANAGER", "cordetfw-examples_2src_2_cr_config_demo_master_2_cr_fw_in_manager_user_par_8h.html#a1a9ff17f6945ef8cd0e2e240a9ec8ae2", null ]
];