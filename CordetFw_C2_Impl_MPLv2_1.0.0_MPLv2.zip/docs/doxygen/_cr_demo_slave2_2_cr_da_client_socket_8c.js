var _cr_demo_slave2_2_cr_da_client_socket_8c =
[
    [ "CrDaClientSocketConfigAction", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#a0b704c6679da5937db6c6972bf83114d", null ],
    [ "CrDaClientSocketInitAction", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#aac6f41c03331ad6e9d6add0ba128d0f2", null ],
    [ "CrDaClientSocketInitCheck", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#a3d31f4597a7641d33be7923010ad4881", null ],
    [ "CrDaClientSocketIsPcktAvail", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#ae5c07ce64b21f8f7505176bbd29957f5", null ],
    [ "CrDaClientSocketPcktCollect", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#a9dc2fe8afd237851522258d17c0fdd22", null ],
    [ "CrDaClientSocketPcktHandover", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#a43839e2d9ba869e8a8214da16e42be94", null ],
    [ "CrDaClientSocketPoll", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#aafe76a6497b9ff55b7bbee753f730531", null ],
    [ "CrDaClientSocketSetHost", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#a4a8e78f6920827e2789f5caf592706c2", null ],
    [ "CrDaClientSocketSetPort", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#aa4050479cc8f1b74b658c6df684a1d76", null ],
    [ "CrDaClientSocketShutdownAction", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#a9f6669254ca8c2ce0b4f287ca289528d", null ],
    [ "hostName", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#a784a41f4628b5ec834b7438939c3c896", null ],
    [ "pcktMaxLength", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#a9e8510c2092c7bffb0542a812076dc64", null ],
    [ "portno", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#a59c2f683fd048491669fd79b2d45caf2", null ],
    [ "readBuffer", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#a52d73daded3ad1972270170b8281faf9", null ],
    [ "sockfd", "_cr_demo_slave2_2_cr_da_client_socket_8c.html#ad2c8fb3df3a737e0685e902870a611d2", null ]
];