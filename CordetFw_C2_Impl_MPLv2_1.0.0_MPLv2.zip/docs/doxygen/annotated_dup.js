var annotated_dup =
[
    [ "CrFwCmpData", "struct_cr_fw_cmp_data.html", "struct_cr_fw_cmp_data" ],
    [ "CrFwErrRep_t", "struct_cr_fw_err_rep__t.html", "struct_cr_fw_err_rep__t" ],
    [ "CrFwInCmdKindDesc_t", "struct_cr_fw_in_cmd_kind_desc__t.html", "struct_cr_fw_in_cmd_kind_desc__t" ],
    [ "CrFwInCmdOutcomeRep_t", "struct_cr_fw_in_cmd_outcome_rep__t.html", "struct_cr_fw_in_cmd_outcome_rep__t" ],
    [ "CrFwInRepKindDesc_t", "struct_cr_fw_in_rep_kind_desc__t.html", "struct_cr_fw_in_rep_kind_desc__t" ],
    [ "CrFwOutCmpKindDesc_t", "struct_cr_fw_out_cmp_kind_desc__t.html", "struct_cr_fw_out_cmp_kind_desc__t" ],
    [ "CrFwPcktQueue", "struct_cr_fw_pckt_queue.html", "struct_cr_fw_pckt_queue" ],
    [ "CrFwServDesc_t", "struct_cr_fw_serv_desc__t.html", "struct_cr_fw_serv_desc__t" ],
    [ "CrFwTrackedState_t", "struct_cr_fw_tracked_state__t.html", "struct_cr_fw_tracked_state__t" ],
    [ "InCmdData", "struct_in_cmd_data.html", "struct_in_cmd_data" ],
    [ "InLoaderData", "struct_in_loader_data.html", "struct_in_loader_data" ],
    [ "InManagerData", "struct_in_manager_data.html", "struct_in_manager_data" ],
    [ "InRepData", "struct_in_rep_data.html", "struct_in_rep_data" ],
    [ "InStreamData", "struct_in_stream_data.html", "struct_in_stream_data" ],
    [ "OutCmpData", "struct_out_cmp_data.html", "struct_out_cmp_data" ],
    [ "OutManagerData", "struct_out_manager_data.html", "struct_out_manager_data" ],
    [ "OutStreamData", "struct_out_stream_data.html", "struct_out_stream_data" ]
];