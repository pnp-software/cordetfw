var struct_out_manager_data =
[
    [ "nextFreePoclPos", "struct_out_manager_data.html#aa616e515da0254ed19176603f35d5445", null ],
    [ "nOfLoadedOutCmp", "struct_out_manager_data.html#afb72ecadef329a62f6af8bc81cd770d8", null ],
    [ "nOfOutCmpInPocl", "struct_out_manager_data.html#a8a6c9268f383ad2397616a6d28b43797", null ],
    [ "pocl", "struct_out_manager_data.html#a6d30a92bb076684dc50f52a99259f416", null ]
];