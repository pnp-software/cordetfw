var group__cr_fw =
[
    [ "Application Start-Up", "group__app_smgroup.html", "group__app_smgroup" ],
    [ "Base Component", "group__base_cmp_group.html", "group__base_cmp_group" ],
    [ "Management of Incoming Commands and Reports", "group__in_mng_group.html", "group__in_mng_group" ],
    [ "Management of Outgoing Commands and Reports", "group__out_mng_group.html", "group__out_mng_group" ],
    [ "Configurable Header Files", "group__cr_config_group.html", "group__cr_config_group" ],
    [ "Unimplemented Interfaces", "group__cr_open_if_group.html", "group__cr_open_if_group" ],
    [ "Auxiliary Functions", "group__aux_group.html", "group__aux_group" ],
    [ "Utility Functions", "group__utility_functions_group.html", "group__utility_functions_group" ],
    [ "Test Suite", "group___cr_test_suite_group.html", "group___cr_test_suite_group" ]
];