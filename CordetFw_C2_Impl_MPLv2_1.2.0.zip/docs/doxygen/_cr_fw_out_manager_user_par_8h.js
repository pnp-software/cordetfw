var _cr_fw_out_manager_user_par_8h =
[
    [ "CR_FW_NOF_OUTMANAGER", "_cr_fw_out_manager_user_par_8h.html#a30cc9c110b74b72846c6b4259253b412", null ],
    [ "CR_FW_OUTMANAGER_POCLSIZE", "_cr_fw_out_manager_user_par_8h.html#a5605909a92f56b98ec73aad729c3667c", null ]
];