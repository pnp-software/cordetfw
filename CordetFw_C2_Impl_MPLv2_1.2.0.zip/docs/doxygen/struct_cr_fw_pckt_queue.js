var struct_cr_fw_pckt_queue =
[
    [ "isEmpty", "struct_cr_fw_pckt_queue.html#ac1cfe56440004a437b8c7da738c235d4", null ],
    [ "nextFreeItem", "struct_cr_fw_pckt_queue.html#a4a9f2651cf1e2b20e5480d32926ecebf", null ],
    [ "oldestItem", "struct_cr_fw_pckt_queue.html#a084434be5fad41e922daa259e36d5ea6", null ],
    [ "pckt", "struct_cr_fw_pckt_queue.html#a12e9407ba8c17e46814f1d00181b94d4", null ],
    [ "size", "struct_cr_fw_pckt_queue.html#a7987b43044cf8f88128f4c12b57cb732", null ]
];