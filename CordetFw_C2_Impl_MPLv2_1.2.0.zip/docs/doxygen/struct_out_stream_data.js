var struct_out_stream_data =
[
    [ "handoverPckt", "struct_out_stream_data.html#a9959f2209751e40acb81c1ad6d513b66", null ],
    [ "pckt", "struct_out_stream_data.html#a2556b94fdf590f572327d68ee5faa96a", null ],
    [ "pcktQueue", "struct_out_stream_data.html#ae20a508e92eb204785a194ed6d06ebdd", null ]
];