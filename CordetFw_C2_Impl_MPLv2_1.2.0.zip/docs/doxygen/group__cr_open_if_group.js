var group__cr_open_if_group =
[
    [ "CrFwAppResetProc.h", "_cr_fw_app_reset_proc_8h.html", null ],
    [ "CrFwAppShutdownProc.h", "_cr_fw_app_shutdown_proc_8h.html", null ],
    [ "CrFwAppStartUpProc.h", "_cr_fw_app_start_up_proc_8h.html", null ],
    [ "CrFwRepErr.h", "_cr_fw_rep_err_8h.html", null ],
    [ "CrFwRepInCmdOutcome.h", "_cr_fw_rep_in_cmd_outcome_8h.html", null ],
    [ "CrFwTime.h", "_cr_fw_time_8h.html", null ],
    [ "CrFwPckt.h", "_cr_fw_pckt_8h.html", null ]
];