var modules =
[
    [ "CORDET Framework", "group__cr_fw.html", "group__cr_fw" ]
];