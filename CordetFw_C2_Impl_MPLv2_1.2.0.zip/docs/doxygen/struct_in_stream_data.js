var struct_in_stream_data =
[
    [ "collectPckt", "struct_in_stream_data.html#aa8476740867ad2fed91f6832dd130fea", null ],
    [ "isPcktAvail", "struct_in_stream_data.html#abb82e0b8ba0632a0b8617a00a23eb873", null ],
    [ "pckt", "struct_in_stream_data.html#a2556b94fdf590f572327d68ee5faa96a", null ],
    [ "pcktQueue", "struct_in_stream_data.html#ae20a508e92eb204785a194ed6d06ebdd", null ]
];