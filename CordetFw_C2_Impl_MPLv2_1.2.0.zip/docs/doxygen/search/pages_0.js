var searchData=
[
  ['adaptation_20points_2419',['Adaptation Points',['../_a_p.html',1,'']]]
];
