var searchData=
[
  ['verified_20items_2421',['Verified Items',['../verify.html',1,'']]]
];
