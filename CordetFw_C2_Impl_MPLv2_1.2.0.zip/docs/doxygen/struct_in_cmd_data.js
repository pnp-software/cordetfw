var struct_in_cmd_data =
[
    [ "abortAction", "struct_in_cmd_data.html#a84f958eac4e32b76310cbb48a8c2760e", null ],
    [ "factoryPoolIndex", "struct_in_cmd_data.html#a5412aae09730b0e377a517993df19312", null ],
    [ "isProgressActionCompleted", "struct_in_cmd_data.html#adc7f7c5952306dabd0fadab817f27e00", null ],
    [ "isReady", "struct_in_cmd_data.html#ac663f021e2196e284d306d70f39e2310", null ],
    [ "isValid", "struct_in_cmd_data.html#a0731344571f510686d6b8ecc5b47d520", null ],
    [ "nOfProgressFailure", "struct_in_cmd_data.html#a27855a99e87ee036aa8badeac2605769", null ],
    [ "pckt", "struct_in_cmd_data.html#a2556b94fdf590f572327d68ee5faa96a", null ],
    [ "progressAction", "struct_in_cmd_data.html#ab2b64c9e41ce3a6c5a7bca925d3820a4", null ],
    [ "progressStepId", "struct_in_cmd_data.html#a1970f2bac241082fbb9439b8b881a239", null ],
    [ "startAction", "struct_in_cmd_data.html#af4ec8345b5d52994e152924d4d68c4ca", null ],
    [ "terminationAction", "struct_in_cmd_data.html#a7df6654da7127e224b8d626629618dfc", null ],
    [ "trackingIndex", "struct_in_cmd_data.html#a1b6ae8ec947ca1e675244f9def681aa3", null ]
];