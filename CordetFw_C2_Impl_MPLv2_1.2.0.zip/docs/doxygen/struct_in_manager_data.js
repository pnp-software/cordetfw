var struct_in_manager_data =
[
    [ "nextFreePcrlPos", "struct_in_manager_data.html#a0bbf6036a60b6d32a1719ee82b2f5656", null ],
    [ "nOfInCmpInPcrl", "struct_in_manager_data.html#a8dc4e3d51512da439e9ed3bd8421f72b", null ],
    [ "nOfLoadedInCmp", "struct_in_manager_data.html#a5b1f438275288be25a51a535abb8f73c", null ],
    [ "pcrl", "struct_in_manager_data.html#aab7d672acd83c9936b8f9441f29be2f0", null ]
];