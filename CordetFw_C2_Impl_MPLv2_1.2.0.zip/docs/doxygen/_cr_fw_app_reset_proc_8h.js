var _cr_fw_app_reset_proc_8h =
[
    [ "CrFwAppSmGetAppResetProc", "_cr_fw_app_reset_proc_8h.html#a97d212ef992d44735bb4efe810eb6a8a", null ]
];